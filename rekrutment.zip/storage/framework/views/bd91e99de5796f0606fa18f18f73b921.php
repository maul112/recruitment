

<?php $__env->startSection('title','Dashboard Pelamar'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard">

    <div class="welcome-card">
        <h1>Halo, <?php echo e(auth()->user()->name); ?> 👋</h1>
        <p>Selamat datang di sistem rekrutmen sekolah. Silakan kelola akun dan lamaran Anda di bawah ini.</p>
    </div>

    <div class="grid md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
        <div class="menu-card">
            <div class="menu-icon">
                <i class="fas fa-user"></i>
            </div>
            <div class="menu-content">
                <a href="<?php echo e(route('pelamar.profile')); ?>">Profil Saya</a>
                <span>Kelola data diri & dokumen</span>
            </div>
        </div>
        
        <div class="menu-card">
            <div class="menu-icon">
                <i class="fas fa-briefcase"></i>
            </div>
            <div class="menu-content">
                <a href="<?php echo e(url('/pelamar/lowongan')); ?>">Lowongan Tersedia</a>
                <span>Lihat dan daftar pekerjaan</span>
            </div>
        </div>

        <div class="menu-card">
            <div class="menu-icon">
                <i class="fas fa-file-alt"></i>
            </div>
            <div class="menu-content">
                <a href="<?php echo e(url('/pelamar/riwayat')); ?>">Lamaran Saya</a>
                <span>Tracking status lamaran</span>
            </div>
        </div>
        
        <div class="menu-card">
            <div class="menu-icon">
                <i class="fas fa-brain"></i>
            </div>
            <div class="menu-content">
                <a href="<?php echo e(route('pelamar.psikotes')); ?>">Psikotes Online</a>
                <span>Kerjakan tes seleksi online</span>
            </div>
        </div>
        
        <div class="menu-card">
            <div class="menu-icon">
                <i class="fas fa-award"></i>
            </div>
            <div class="menu-content">
                <a href="<?php echo e(route('pelamar.pengumuman')); ?>">Hasil Seleksi</a>
                <span>Lihat kelulusan tahap akhir</span>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ardic\Kuliah\Tugas kuliah\project\rekruitment\resources\views/pelamar/dashboard.blade.php ENDPATH**/ ?>