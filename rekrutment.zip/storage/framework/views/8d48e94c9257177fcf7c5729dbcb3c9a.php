

<?php $__env->startSection('title','Daftar Lamaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full">
    <h3 class="mb-2 text-2xl">Daftar Lamaran Pelamar</h3>

    <?php if(session('success')): ?>
        <div style="color:green"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <!-- TABLE -->
    <div class="table-scroll" style="overflow-x:auto; width:100%;">
        <table>
            <thead style="background:#f3f4f6; text-align:left;">
                <tr>
                    <th style="padding:12px;">ID</th>
                    <th style="padding:12px;">Pelamar</th>
                    <th style="padding:12px;">Lowongan</th>
                    <th style="padding:12px;">Tanggal Daftar</th>
                    <th style="padding:12px;">Status</th>
                    <th style="padding:12px;">Total Nilai</th>
                    <th style="padding:12px;">Aksi</th>
                </tr>
            </thead>
            <tbody id="tableBody">
                <?php $__empty_1 = true; $__currentLoopData = $lamarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="row-anim">
                    <td style="padding:12px;"><strong><?php echo e($l->id); ?></strong></td>

                    <td style="padding:12px;"><?php echo e($l->pelamar->nama_lengkap); ?></td>

                    <td style="padding:12px;"><?php echo e($l->lowongan->posisi); ?></td>

                    <td style="padding:12px;"><?php echo e($l->tanggal_daftar); ?></td>

                    <td style="padding:12px;"><?php echo e($l->status); ?></td>

                    <td style="padding:12px;"><?php echo e($l->total_nilai); ?></td>

                    <td class="actions" style="padding:12px; display:flex; gap:8px; flex-wrap:wrap;">
                        <a class="btn" href="<?php echo e(route('admin.lamaran.edit', $l->id)); ?>">Edit</a>
                    </td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" style="text-align:center; padding:45px;">
                        <img src="https://cdn-icons-png.flaticon.com/512/4076/4076432.png" width="80">
                        <p style="margin-top:15px; color:#6b7280;">Belum ada lowongan yang ditambahkan</p>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ardic\Kuliah\Tugas kuliah\project\rekruitment\resources\views/admin/lamaran/index.blade.php ENDPATH**/ ?>