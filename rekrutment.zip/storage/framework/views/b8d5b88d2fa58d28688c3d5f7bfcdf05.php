

<?php $__env->startSection('title','Buat Psikotes'); ?>

<?php $__env->startSection('content'); ?>
<h3>Buat Psikotes Baru</h3>

<form action="<?php echo e(route('admin.psikotes.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label>Lamaran Pelamar:</label>
    <select name="lamaran_id" required>
        <?php $__currentLoopData = $lamaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($l->id); ?>"><?php echo e($l->pelamar->nama); ?> - <?php echo e($l->posisi); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br>
    <label>Mulai Tes:</label>
    <input type="datetime-local" name="mulai_at">
    <br>
    <label>Selesai Tes:</label>
    <input type="datetime-local" name="selesai_at">
    <br>
    <button type="submit">Simpan</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rekruitment\resources\views/admin/psikotes/create.blade.php ENDPATH**/ ?>