

<?php $__env->startSection('title','Tambah Lowongan'); ?>

<?php $__env->startSection('content'); ?>
<form class="form-content" method="POST" action="/admin/lowongan/store">
    <?php echo csrf_field(); ?>

    <label>Posisi</label>
    <input type="text" 
           name="posisi" 
           value="<?php echo e(old('posisi')); ?>" 
           required>

    <label>Deskripsi</label>
    <textarea name="deskripsi" rows="4"><?php echo e(old('deskripsi')); ?></textarea>

    <label>Kualifikasi Pendidikan</label>
    <input type="text" 
           name="kualifikasi_pendidikan" 
           value="<?php echo e(old('kualifikasi_pendidikan')); ?>">

    <div style="display:flex; gap:15px;">
        <div style="flex:1;">
            <label>Tanggal Buka</label>
            <input type="date" 
                   name="tanggal_buka" 
                   value="<?php echo e(old('tanggal_buka')); ?>">
        </div>

        <div style="flex:1;">
            <label>Tanggal Tutup</label>
            <input type="date" 
                   name="tanggal_tutup" 
                   value="<?php echo e(old('tanggal_tutup')); ?>">
        </div>
    </div>

    <label>Dokumen Wajib</label>
    <textarea name="dokumen_wajib" rows="3"><?php echo e(old('dokumen_wajib')); ?></textarea>

    <div style="display:flex; gap:15px;">
        <div style="flex:1;">
            <label>Kuota</label>
            <input type="number" 
                   name="kuota" 
                   min="1"
                   value="<?php echo e(old('kuota', 1)); ?>">
        </div>

        <div style="flex:1;">
            <label>Status</label>
            <select name="status">
                <option value="draft">Draft</option>
                <option value="published">Published</option>
                <option value="closed">Closed</option>
            </select>
        </div>
    </div>

    <!-- Tombol sejajar: Kembali kiri, Simpan kanan -->
    <div style="display:flex; width:100%; margin-top:10px; gap:5px;">
        <a href="<?php echo e(url('/admin/lowongan')); ?>" 
            class="btn" 
            style="flex:1; background:#f3f4f6; color:#111; padding:10px 0; border-radius:8px; text-align:center;">
            Kembali
        </a>

        <button type="submit" 
                class="btn" 
                style="flex:1; background:#2563eb; color:white; padding:10px 0; border-radius:8px; text-align:center;">
            Simpan Lowongan
        </button>
    </div>

</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rekruitment\resources\views/admin/lowongan/create.blade.php ENDPATH**/ ?>