

<?php $__env->startSection('title','Profil Pelamar'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <h2>Profil Pelamar</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('pelamar.profile.update')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <!-- DATA DASAR -->
        <div class="section-card">
            <h3>Data Dasar</h3>
            <div class="form-group">
                <label>Nama Lengkap *</label>
                <input type="text" name="nama_lengkap" 
                    value="<?php echo e(old('nama_lengkap', $pelamar->nama_lengkap ?? Auth::user()->name ?? '')); ?>" 
                    required>
            </div>
            <div class="form-group">
                <label>NIK *</label>
                <input type="text" name="nik" value="<?php echo e(old('nik', $pelamar->nik ?? '')); ?>" required>
            </div>
            <div class="form-group">
                <label>Tanggal Lahir *</label>
                <input type="date" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir', $pelamar->tanggal_lahir ?? '')); ?>" required>
            </div>
            <div class="form-group">
                <label>Jenis Kelamin *</label>
                <select name="jenis_kelamin" required>
                    <option value="">Pilih</option>
                    <option value="Laki-laki" <?php echo e((old('jenis_kelamin',$pelamar->jenis_kelamin ?? '')=='Laki-laki')?'selected':''); ?>>Laki-laki</option>
                    <option value="Perempuan" <?php echo e((old('jenis_kelamin',$pelamar->jenis_kelamin ?? '')=='Perempuan')?'selected':''); ?>>Perempuan</option>
                </select>
            </div>
            <div class="form-group">
                <label>Alamat *</label>
                <textarea name="alamat" required><?php echo e(old('alamat',$pelamar->alamat ?? '')); ?></textarea>
            </div>
        </div>

        <!-- DATA PENDIDIKAN & DOKUMEN -->
        <div class="section-card">
            <h3>Data Pendidikan & Dokumen</h3>
            <div class="form-group">
                <label>Pendidikan Terakhir</label>
                <input type="text" name="pendidikan_terakhir" value="<?php echo e(old('pendidikan_terakhir',$pelamar->pendidikan_terakhir ?? '')); ?>">
            </div>
            <div class="form-group">
                <label>Prodi</label>
                <input type="text" name="prodi" value="<?php echo e(old('prodi',$pelamar->prodi ?? '')); ?>">
            </div>
            <div class="form-group">
                <label>Universitas</label>
                <input type="text" name="universitas" value="<?php echo e(old('universitas',$pelamar->universitas ?? '')); ?>">
            </div>
            <div class="form-group">
                <label>CV (PDF)</label>
                <input type="file" name="cv_path">
            </div>
            <div class="form-group">
                <label>Ijazah (PDF)</label>
                <input type="file" name="ijazah_path">
            </div>
            <div class="form-group">
                <label>Transkrip Nilai (PDF)</label>
                <input type="file" name="transkrip_path">
            </div>
            <div class="form-group">
                <label>Pas Foto (JPG/PNG)</label>
                <input type="file" name="pas_foto_path">
            </div>
            <div class="form-group">
                <label>Sertifikat (PDF)</label>
                <input type="file" name="sertifikat_path">
            </div>
        </div>

        <button type="submit" class="btn-submit">Simpan Profil</button>
    </form>
</div>

<style>
/* Wrapper */
.content-wrapper {
    max-width:720px;
    margin:auto;
    background: #ffffff;
    padding:30px 35px;
    border-radius:20px;
    box-shadow:0 15px 35px rgba(0,0,0,0.07);
    margin-top:40px;
    margin-bottom:40px;
    font-family: 'Poppins', sans-serif;
}

/* Headings */
h2 { font-weight:700; color:#1e293b; margin-bottom:25px; text-align:center;}
h3 { font-weight:600; color:#334155; margin-bottom:15px; border-bottom:2px solid #e2e8f0; padding-bottom:5px; }

/* Section Cards */
.section-card {
    background:#f8fafc;
    padding:20px 25px;
    border-radius:15px;
    margin-bottom:25px;
    transition:0.3s;
}
.section-card:hover {
    background:#eef2ff;
}

/* Form Groups */
.form-group { margin-bottom:15px; }
label { display:block; font-weight:600; margin-bottom:5px; color:#475569; }
input, select, textarea {
    width:100%;
    padding:10px 15px;
    border-radius:10px;
    border:1px solid #cbd5e1;
    outline:none;
    transition:0.3s;
}
input:focus, select:focus, textarea:focus {
    border-color:#2563eb;
    box-shadow:0 2px 8px rgba(37,99,235,0.2);
}

/* Button */
.btn-submit {
    width:100%;
    padding:12px 0;
    background: linear-gradient(135deg,#2563eb,#1e3a8a);
    border:none;
    border-radius:15px;
    color:white;
    font-weight:700;
    font-size:16px;
    cursor:pointer;
    transition:0.3s;
}
.btn-submit:hover {
    transform:translateY(-2px) scale(1.02);
    box-shadow:0 8px 20px rgba(37,99,235,0.3);
}

/* Alerts */
.alert {
    padding:12px 18px;
    border-radius:12px;
    margin-top:10px;
    font-weight:600;
}
.alert-success { background:#16a34a; color:white; }
.alert-danger { background:#dc2626; color:white; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rekruitment\resources\views/pelamar/profile.blade.php ENDPATH**/ ?>