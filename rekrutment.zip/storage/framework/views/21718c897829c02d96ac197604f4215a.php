

<?php $__env->startSection('title','Kontrak'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full">
    <div class="flex justify-between mb-2">
        <h3 class="text-2xl mb-2">Daftar Kontrak</h3>
        <a class="py-2 px-4 rounded-lg bg-blue-600 text-white transition-all duration-300 hover:shadow-2xl" href="<?php echo e(route('admin.kontrak.create')); ?>">+ Tambah Kontrak</a>
    </div>
    <table border="1" cellpadding="8" cellspacing="0">
        <tr>
            <th style="padding: 12px;">ID</th>
            <th style="padding: 12px;">Pelamar</th>
            <th style="padding: 12px;">Posisi</th>
            <th style="padding: 12px;">Status</th>
            <th style="padding: 12px;">Aksi</th>
        </tr>
        <?php $__currentLoopData = $kontrak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($k->id); ?></td>
            <td><?php echo e($k->lamaran->pelamar->nama); ?></td>
            <td><?php echo e($k->lamaran->posisi); ?></td>
            <td><?php echo e($k->status); ?></td>
            <td>
                <a href="<?php echo e(route('admin.kontrak.show', $k->id)); ?>">Detail</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ardic\Kuliah\Tugas kuliah\project\rekruitment\resources\views/admin/kontrak/index.blade.php ENDPATH**/ ?>