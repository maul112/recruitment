

<?php $__env->startSection('title','Detail Wawancara'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full">
    <h3 class="mb-4">Detail Wawancara</h3>
    
    
    <div style="margin-bottom:20px;">
        <strong>Pelamar:</strong> <?php echo e($wawancara->lamaran->pelamar->nama_lengkap); ?> <br>
        <strong>Posisi Lamaran:</strong> <?php echo e($wawancara->lamaran->lowongan->posisi); ?> <br>
        <strong>Tipe Wawancara:</strong> <?php echo e($wawancara->tipe); ?> <br>
        <strong>Jadwal:</strong> <?php echo e($wawancara->jadwal ?? '-'); ?> <br>
        <strong>Lokasi:</strong> <?php echo e($wawancara->lokasi ?? '-'); ?> <br>
    </div>
    
    <hr>
    
    
    <form action="<?php echo e(route('admin.wawancara.update', $wawancara->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <h4 class="mb-4">Penilaian Wawancara (Skala 10-100)</h4>
        <?php $__currentLoopData = $aspek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label><?php echo e($a); ?>:</label>
            <input class="border rounded-md mb-4 ml-2 p-2" type="number" name="nilai_<?php echo e($a); ?>" min="10" max="100" value="<?php echo e($wawancara['nilai_' . $a] ?? ''); ?>" required>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
        <label>Komentar:</label><br>
        <textarea class="border rounded-md p-2 w-full" name="komentar" rows="4"><?php echo e($wawancara->komentar); ?></textarea>
        <br>
        <button class="btn" type="submit">Simpan Penilaian</button>
    </form>
    
    
    <?php if($wawancara->nilai): ?>
    <div style="margin-top:20px;">
        <strong>Nilai Wawancara:</strong> <?php echo e($wawancara->nilai); ?> <br>
        <strong>Komentar:</strong> <?php echo e($wawancara->komentar ?? '-'); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ardic\Kuliah\Tugas kuliah\project\rekruitment\resources\views/admin/wawancara/show.blade.php ENDPATH**/ ?>