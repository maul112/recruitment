

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="cards">
    <div class="card">
        <h3>120+</h3>
        <p>Total Pelamar</p>
    </div>

    <div class="card">
        <h3>25</h3>
        <p>Lowongan Aktif</p>
    </div>

    <div class="card">
        <h3>68</h3>
        <p>Sudah Tes</p>
    </div>

    <div class="card">
        <h3>20</h3>
        <p>Diterima</p>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rekruitment\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>