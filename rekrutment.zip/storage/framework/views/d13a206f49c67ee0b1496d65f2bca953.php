

<?php $__env->startSection('title','Tambah Kontrak'); ?>

<?php $__env->startSection('content'); ?>
<h3>Tambah Kontrak</h3>

<form action="<?php echo e(route('admin.kontrak.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label>Lamaran Pelamar:</label>
    <select name="lamaran_id" required>
        <?php $__currentLoopData = $lamaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($l->id); ?>"><?php echo e($l->pelamar->nama); ?> - <?php echo e($l->posisi); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br>

    <label>File Kontrak:</label>
    <input type="file" name="file_kontrak" required>
    <br>

    <label>Signature (opsional):</label>
    <input type="file" name="signature">
    <br>

    <label>Tanggal Ditandatangani (opsional):</label>
    <input type="datetime-local" name="signed_at">
    <br>

    <label>Status:</label>
    <select name="status">
        <option value="belum">Belum</option>
        <option value="ditandatangani">Ditandatangani</option>
    </select>
    <br>

    <button type="submit">Simpan Kontrak</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ardic\Kuliah\Tugas kuliah\project\rekruitment\resources\views/admin/kontrak/create.blade.php ENDPATH**/ ?>