

<?php $__env->startSection('title','Psikotes'); ?>

<?php $__env->startSection('content'); ?>
<h3>Daftar Psikotes Pelamar</h3>
<a href="<?php echo e(route('admin.psikotes.create')); ?>">Buat Psikotes Baru</a>
<table border="1" cellpadding="8" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Pelamar</th>
        <th>Status</th>
        <th>Skor</th>
        <th>Rekomendasi</th>
        <th>Aksi</th>
    </tr>
    <?php $__currentLoopData = $psikotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($p->id); ?></td>
        <td><?php echo e($p->lamaran->pelamar->nama); ?></td>
        <td><?php echo e($p->status); ?></td>
        <td><?php echo e($p->skor_kognitif ?? '-'); ?></td>
        <td><?php echo e($p->rekomendasi ?? '-'); ?></td>
        <td>
            <a href="<?php echo e(route('admin.psikotes.show', $p->id)); ?>">Lihat</a>
            <?php if($p->status=='belum'): ?>
                <form action="<?php echo e(route('admin.psikotes.nilai',$p->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <button type="submit">Nilai Otomatis</button>
                </form>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rekruitment\resources\views/admin/psikotes/index.blade.php ENDPATH**/ ?>