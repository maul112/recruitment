<?php $__env->startSection('title','Detail Psikotes'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full">
    <div class="flex justify-between">
        <div>
            <h3>Detail Psikotes</h3>
        
            
            <div style="margin-bottom:20px;">
                <strong>Pelamar:</strong> <?php echo e($psikotes->lamaran->pelamar->nama); ?> <br>
                <strong>Posisi Lamaran:</strong> <?php echo e($psikotes->lamaran->posisi); ?> <br>
                <strong>Status Psikotes:</strong> <?php echo e($psikotes->status); ?> <br>
                <strong>Mulai Tes:</strong> <?php echo e($psikotes->mulai_at ?? '-'); ?> <br>
                <strong>Selesai Tes:</strong> <?php echo e($psikotes->selesai_at ?? '-'); ?> <br>
            </div>
        </div>
        <div>
            
            <?php if($psikotes->status=='belum'): ?>
            <form action="<?php echo e(route('admin.psikotes.nilai',$psikotes->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="btn" type="submit">Nilai Otomatis</button>
            </form>
            <?php endif; ?>
        </div>
    </div>


    <hr>

    
    <table border="1" cellpadding="8" cellspacing="0" width="100%">
        <tr>
            <th style="padding: 12px;">No</th>
            <th style="padding: 12px;">Soal</th>
            <th style="padding: 12px;">Jawaban Pelamar</th>
            <th style="padding: 12px;">Kunci Jawaban</th>
            <th style="padding: 12px;">Status</th>
            <th style="padding: 12px;">Nilai</th>
        </tr>
        <?php $__currentLoopData = $psikotes->jawaban; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="padding: 12px;"><?php echo e($index+1); ?></td>
            <td style="padding: 12px;"><?php echo e($j->soal->pertanyaan); ?></td>
            <td style="padding: 12px;"><?php echo e($j->jawaban ?? '-'); ?></td>
            <td style="padding: 12px;"><?php echo e($j->soal->kunci_jawaban); ?></td>
            <td style="padding: 12px;">
                <?php if($j->benar === null): ?>
                    -
                <?php elseif($j->benar): ?>
                    Benar
                <?php else: ?>
                    Salah
                <?php endif; ?>
            </td>
            <td style="padding: 12px;"><?php echo e($j->nilai ?? '-'); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    
    <div style="margin-top:20px;">
        <strong>Total Skor Kognitif:</strong> <?php echo e($psikotes->skor_kognitif ?? '-'); ?> <br>
        <strong>Profil Kepribadian:</strong> <?php echo e($psikotes->profil_kepribadian ?? '-'); ?> <br>
        <strong>Rekomendasi:</strong> <?php echo e($psikotes->rekomendasi ?? '-'); ?> <br>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ardic\Kuliah\Tugas kuliah\project\rekruitment\resources\views/admin/psikotes/show.blade.php ENDPATH**/ ?>