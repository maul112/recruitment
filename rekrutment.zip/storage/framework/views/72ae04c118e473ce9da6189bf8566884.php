

<?php $__env->startSection('title','Edit Lamaran'); ?>

<?php $__env->startSection('content'); ?>
<h3>Edit Lamaran</h3>

<form method="POST" action="<?php echo e(route('admin.lamaran.update', $lamaran->id)); ?>">
    <?php echo csrf_field(); ?>
    <label>Status:</label>
    <select name="status" required>
        <option value="terkirim" <?php echo e($lamaran->status=='terkirim' ? 'selected':''); ?>>Terkirim</option>
        <option value="verifikasi" <?php echo e($lamaran->status=='verifikasi' ? 'selected':''); ?>>Verifikasi</option>
        <option value="ditolak_adm" <?php echo e($lamaran->status=='ditolak_adm' ? 'selected':''); ?>>Ditolak Admin</option>
        <option value="psikotes" <?php echo e($lamaran->status=='psikotes' ? 'selected':''); ?>>Psikotes</option>
        <option value="wawancara" <?php echo e($lamaran->status=='wawancara' ? 'selected':''); ?>>Wawancara</option>
        <option value="diterima" <?php echo e($lamaran->status=='diterima' ? 'selected':''); ?>>Diterima</option>
    </select>

    <label>Catatan Admin:</label>
    <textarea name="catatan_admin"><?php echo e($lamaran->catatan_admin); ?></textarea>

    <label>Nilai Administrasi:</label>
    <input type="number" name="nilai_administrasi" value="<?php echo e($lamaran->nilai_administrasi); ?>">

    <label>Nilai Psikotes:</label>
    <input type="number" name="nilai_psikotes" value="<?php echo e($lamaran->nilai_psikotes); ?>">

    <label>Nilai Wawancara:</label>
    <input type="number" name="nilai_wawancara" value="<?php echo e($lamaran->nilai_wawancara); ?>">

    <button type="submit">Simpan</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rekruitment\resources\views/admin/lamaran/edit.blade.php ENDPATH**/ ?>