

<?php $__env->startSection('title','Daftar Lamaran'); ?>

<?php $__env->startSection('content'); ?>
<h3>Daftar Lamaran Pelamar</h3>

<?php if(session('success')): ?>
    <div style="color:green"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<table border="1" cellpadding="8" cellspacing="0">
    <thead>
        <tr>
            <th>ID</th>
            <th>Pelamar</th>
            <th>Lowongan</th>
            <th>Tanggal Daftar</th>
            <th>Status</th>
            <th>Total Nilai</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $lamarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($l->id); ?></td>
            <td><?php echo e($l->pelamar->nama); ?></td>
            <td><?php echo e($l->lowongan->posisi); ?></td>
            <td><?php echo e($l->tanggal_daftar); ?></td>
            <td><?php echo e($l->status); ?></td>
            <td><?php echo e($l->total_nilai); ?></td>
            <td>
                <a href="<?php echo e(route('admin.lamaran.edit', $l->id)); ?>">Edit</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rekruitment\resources\views/admin/lamaran/index.blade.php ENDPATH**/ ?>