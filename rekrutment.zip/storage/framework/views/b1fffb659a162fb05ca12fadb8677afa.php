

<?php $__env->startSection('title','Buat Wawancara'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full">

    <h3 class="text-2xl mb-2">Buat Wawancara Baru</h3>

    <form action="<?php echo e(route('admin.wawancara.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label>Lamaran Pelamar:</label>
        <select name="lamaran_id" required>
            <?php $__currentLoopData = $lamaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($l->id); ?>"><?php echo e($l->pelamar->nama_lengkap); ?> - <?php echo e($l->lowongan->posisi); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>

        <label>Tipe Wawancara:</label>
        <select name="tipe" required>
            <option value="HRD">HRD</option>
            <option value="Kepala Sekolah">Kepala Sekolah</option>
            <option value="Microteaching">Microteaching</option>
        </select>
        <br>

        <label>Jadwal:</label>
        <input type="datetime-local" name="jadwal">
        <br>

        <label>Lokasi:</label>
        <input type="text" name="lokasi">
        <br>

        <button class="bg-blue-600 text-white py-2 px-4 rounded-xl" type="submit">Simpan</button>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ardic\Kuliah\Tugas kuliah\project\rekruitment\resources\views/admin/wawancara/create.blade.php ENDPATH**/ ?>