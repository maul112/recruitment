

<?php $__env->startSection('title','Kontrak'); ?>

<?php $__env->startSection('content'); ?>
<h3>Daftar Kontrak</h3>
<a href="<?php echo e(route('admin.kontrak.create')); ?>">Tambah Kontrak</a>
<table border="1" cellpadding="8" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Pelamar</th>
        <th>Posisi</th>
        <th>Status</th>
        <th>Aksi</th>
    </tr>
    <?php $__currentLoopData = $kontrak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($k->id); ?></td>
        <td><?php echo e($k->lamaran->pelamar->nama); ?></td>
        <td><?php echo e($k->lamaran->posisi); ?></td>
        <td><?php echo e($k->status); ?></td>
        <td>
            <a href="<?php echo e(route('admin.kontrak.show', $k->id)); ?>">Detail</a>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rekruitment\resources\views/admin/kontrak/index.blade.php ENDPATH**/ ?>