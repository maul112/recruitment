

<?php $__env->startSection('title','Wawancara'); ?>

<?php $__env->startSection('content'); ?>
<h3>Daftar Wawancara</h3>
<a href="<?php echo e(route('admin.wawancara.create')); ?>">Buat Wawancara Baru</a>
<table border="1" cellpadding="8" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Pelamar</th>
        <th>Posisi</th>
        <th>Tipe</th>
        <th>Jadwal</th>
        <th>Nilai</th>
        <th>Aksi</th>
    </tr>
    <?php $__currentLoopData = $wawancara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($w->id); ?></td>
        <td><?php echo e($w->lamaran->pelamar->nama); ?></td>
        <td><?php echo e($w->lamaran->posisi); ?></td>
        <td><?php echo e($w->tipe); ?></td>
        <td><?php echo e($w->jadwal ?? '-'); ?></td>
        <td><?php echo e($w->nilai ?? '-'); ?></td>
        <td>
            <a href="<?php echo e(route('admin.wawancara.show', $w->id)); ?>">Detail</a>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rekruitment\resources\views/admin/wawancara/index.blade.php ENDPATH**/ ?>