

<?php $__env->startSection('title','Edit Lamaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full">
    <h3 class="mb-2 text-2xl">Edit Lamaran</h3>

    <form method="POST" action="<?php echo e(route('admin.lamaran.update', $lamaran->id)); ?>">
        <?php echo csrf_field(); ?>
        <label class="block my-2">Status:</label>
        <select class="border rounded-md p-2" name="status" required>
            <option value="terkirim" <?php echo e($lamaran->status=='terkirim' ? 'selected':''); ?>>Terkirim</option>
            <option value="verifikasi" <?php echo e($lamaran->status=='verifikasi' ? 'selected':''); ?>>Verifikasi</option>
            <option value="ditolak_adm" <?php echo e($lamaran->status=='ditolak_adm' ? 'selected':''); ?>>Ditolak Admin</option>
            <option value="psikotes" <?php echo e($lamaran->status=='psikotes' ? 'selected':''); ?>>Psikotes</option>
            <option value="wawancara" <?php echo e($lamaran->status=='wawancara' ? 'selected':''); ?>>Wawancara</option>
            <option value="lulus" <?php echo e($lamaran->status=='lulus' ? 'selected':''); ?>>Diterima</option>
        </select>

        <label class="block my-2">Catatan Admin:</label>
        <textarea class="w-full border rounded-md p-2" name="catatan_admin"><?php echo e($lamaran->catatan_admin); ?></textarea>

        <label class="block my-2">Nilai Administrasi:</label>
        <input class="border rounded-md p-2" type="number" name="nilai_administrasi" value="<?php echo e($lamaran->nilai_administrasi); ?>">

        <label class="block my-2">Nilai Psikotes:</label>
        <input class="border rounded-md p-2" type="number" name="nilai_psikotes" value="<?php echo e($lamaran->nilai_psikotes); ?>">

        <label class="block my-2">Nilai Wawancara:</label>
        <input class="border rounded-md p-2" type="number" name="nilai_wawancara" value="<?php echo e($lamaran->nilai_wawancara); ?>">

        <button class="block mt-4 py-2 px-4 bg-blue-500 rounded-xl text-white hover:scale-105 transition-all duration-200 hover:shadow-2xl" type="submit">Simpan</button>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ardic\Kuliah\Tugas kuliah\project\rekruitment\resources\views/admin/lamaran/edit.blade.php ENDPATH**/ ?>