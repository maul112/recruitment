@extends('layouts.admin')

@section('title', 'Dashboard')

@section('content')

<div class="cards">
    <div class="card">
        <h3>120+</h3>
        <p>Total Pelamar</p>
    </div>

    <div class="card">
        <h3>25</h3>
        <p>Lowongan Aktif</p>
    </div>

    <div class="card">
        <h3>68</h3>
        <p>Sudah Tes</p>
    </div>

    <div class="card">
        <h3>20</h3>
        <p>Diterima</p>
    </div>
</div>

@endsection
